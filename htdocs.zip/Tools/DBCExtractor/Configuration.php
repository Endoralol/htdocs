<?php

global $FCCore;

$FCCore['DataDirectory']			=	"data/";
$FCCore['IconsDirectory']			=	"icons/";
$FCCore['Maps']						=	"maps/";
$FCCore['English']					=	"DBC/";
$FCCore['Localized']				=	"DBCLocalized/";
$FCCore['Locale']					=	"8";

$FCCore['English335a']					=	"3.3.5a/DBC/";
$FCCore['Localized335a']				=	"3.3.5a/DBCLocalized/";
$FCCore['English548']					=	"5.4.8/DBC/";
$FCCore['Localized548']				    =	"5.4.8/DBCLocalized/";
$FCCore['English6x']					=	"6.x/DBC/";
$FCCore['Localized6x']				    =	"6.x/DBCLocalized/";

?>