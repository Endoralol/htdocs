<?php
	header('Location: /');
?>