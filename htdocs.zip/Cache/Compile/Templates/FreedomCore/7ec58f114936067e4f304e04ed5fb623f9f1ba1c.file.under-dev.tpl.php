<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-04 03:11:19
         compiled from "/opt/lampp/htdocs/Templates/FreedomCore/sidebar/under-dev.tpl" */ ?>
<?php /*%%SmartyHeaderCode:177342642657521ca7819ef5-26705966%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7ec58f114936067e4f304e04ed5fb623f9f1ba1c' => 
    array (
      0 => '/opt/lampp/htdocs/Templates/FreedomCore/sidebar/under-dev.tpl',
      1 => 1464860670,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '177342642657521ca7819ef5-26705966',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57521ca784b1a4_29216247',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57521ca784b1a4_29216247')) {function content_57521ca784b1a4_29216247($_smarty_tpl) {?><div class="sidebar-module" id="sidebar-under-dev">
    <div class="sidebar-title">
        <h3 class="header-3 title-under-dev"><?php echo $_smarty_tpl->getConfigVariable('Latest_Updates_Title');?>
</h3>
    </div>

    <div class="sidebar-content">
        <a href="/wow/en/game/patch-notes/6-0">
            <div class="patch-banner"></div>

            <div class="patch-banner-text">
                The Warlords of Draenor Patch is Live!
            </div></a>
    </div>
</div><?php }} ?>
