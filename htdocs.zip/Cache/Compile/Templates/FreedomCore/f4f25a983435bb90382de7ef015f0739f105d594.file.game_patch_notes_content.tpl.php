<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-04 13:50:20
         compiled from "/opt/lampp/htdocs/Templates/FreedomCore/pages/game_patch_notes_content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:5079257235752b26c64b9e8-80702196%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'f4f25a983435bb90382de7ef015f0739f105d594' => 
    array (
      0 => '/opt/lampp/htdocs/Templates/FreedomCore/pages/game_patch_notes_content.tpl',
      1 => 1464860666,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '5079257235752b26c64b9e8-80702196',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5752b26c64c159_35557944',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5752b26c64c159_35557944')) {function content_5752b26c64c159_35557944($_smarty_tpl) {?><?php }} ?>
