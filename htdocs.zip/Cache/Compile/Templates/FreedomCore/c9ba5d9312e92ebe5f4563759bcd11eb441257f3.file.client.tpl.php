<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-04 03:11:19
         compiled from "/opt/lampp/htdocs/Templates/FreedomCore/sidebar/client.tpl" */ ?>
<?php /*%%SmartyHeaderCode:146839200057521ca7793e67-91700795%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    'c9ba5d9312e92ebe5f4563759bcd11eb441257f3' => 
    array (
      0 => '/opt/lampp/htdocs/Templates/FreedomCore/sidebar/client.tpl',
      1 => 1464860670,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '146839200057521ca7793e67-91700795',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'AppName' => 0,
    'Language' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57521ca77cd065_88167121',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57521ca77cd065_88167121')) {function content_57521ca77cd065_88167121($_smarty_tpl) {?><div id="sidebar-marketing" class="sidebar-module">
    <div class="bnet-offer">
        <div class="bnet-offer-bg">
            <a href="#" target="_blank" id="<?php echo $_smarty_tpl->tpl_vars['AppName']->value;?>
-client" class="bnet-offer-image">
                <img src="/Templates/FreedomCore/images/client/app-screen-<?php echo $_smarty_tpl->tpl_vars['Language']->value;?>
.png" width="300" height="250" alt="" />
            </a>
        </div>
    </div>
</div><?php }} ?>
