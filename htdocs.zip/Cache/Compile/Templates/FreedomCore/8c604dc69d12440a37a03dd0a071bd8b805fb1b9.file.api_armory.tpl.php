<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-04 07:44:44
         compiled from "/opt/lampp/htdocs/Templates/FreedomCore/developer/api_armory.tpl" */ ?>
<?php /*%%SmartyHeaderCode:24908337557525cbc9874d2-73613264%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '8c604dc69d12440a37a03dd0a071bd8b805fb1b9' => 
    array (
      0 => '/opt/lampp/htdocs/Templates/FreedomCore/developer/api_armory.tpl',
      1 => 1464860660,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '24908337557525cbc9874d2-73613264',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57525cbc9cb6c4_37879343',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57525cbc9cb6c4_37879343')) {function content_57525cbc9cb6c4_37879343($_smarty_tpl) {?><li class="endpoint">
    <h3 class="header-3 title-api-key">
        Armory API
    </h3>
    <?php echo $_smarty_tpl->getSubTemplate ('developer/api_armory_reset.tpl', $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

    <br />
</li><?php }} ?>
