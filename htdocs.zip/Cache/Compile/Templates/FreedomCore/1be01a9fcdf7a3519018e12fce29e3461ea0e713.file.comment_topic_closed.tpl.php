<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-04 10:55:10
         compiled from "/opt/lampp/htdocs/Templates/FreedomCore/forum/comment_topic_closed.tpl" */ ?>
<?php /*%%SmartyHeaderCode:245645325752895e6ab754-42650702%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1be01a9fcdf7a3519018e12fce29e3461ea0e713' => 
    array (
      0 => '/opt/lampp/htdocs/Templates/FreedomCore/forum/comment_topic_closed.tpl',
      1 => 1464860661,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '245645325752895e6ab754-42650702',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5752895e726672_42245471',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5752895e726672_42245471')) {function content_5752895e726672_42245471($_smarty_tpl) {?><div id="new-post" class="posting-status-message">
			<?php echo $_smarty_tpl->getConfigVariable('Forum_Topic_Clodsed');?>

	</div><?php }} ?>
