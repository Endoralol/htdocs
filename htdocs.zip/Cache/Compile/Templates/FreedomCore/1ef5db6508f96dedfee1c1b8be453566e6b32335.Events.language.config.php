<?php $_config_vars = array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
  ),
); ?>