<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-04 05:08:02
         compiled from "/opt/lampp/htdocs/Templates/FreedomCore/forum/comment_not_logged.tpl" */ ?>
<?php /*%%SmartyHeaderCode:45940991457523802db38e6-71601659%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '473dbe84b53d11eb9264978ba1a4098363dab80a' => 
    array (
      0 => '/opt/lampp/htdocs/Templates/FreedomCore/forum/comment_not_logged.tpl',
      1 => 1464860661,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '45940991457523802db38e6-71601659',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57523802db66a7_71524411',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57523802db66a7_71524411')) {function content_57523802db66a7_71524411($_smarty_tpl) {?><div id="new-post" class="bottom-reply-wrapper">
	<table class="dynamic-center ">
		<tr>
			<td>




	<div class="reply-button-wrapper ajax-update">

<a class="ui-button button1" href="/account/login"
onclick="return Login.open();"><span class="button-left"><span class="button-right"> <?php echo $_smarty_tpl->getConfigVariable('Forum_Reply');?>

</span></span></a>

	</div>

</td>
		</tr>
	</table>
				</div><?php }} ?>
