<?php $_config_vars = array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'Developer_Page_Title' => 'For Developers',
    'Developer_API_Header' => 'API',
    'Developer_API_Settings' => 'Settings',
    'Developer_API_Key' => 'Your API key',
    'Developer_Authorization_Needed' => 'To request API key you must be authorized',
    'Developer_API_Key_Get' => 'Request Key',
    'Developer_Form_Parameter' => 'Parameter',
    'Developer_Form_Value' => 'Value',
    'Developer_Form_Description' => 'Description',
    'Developer_Form_TryIt' => 'Try It!',
    'Developer_Form_Reset' => 'Clear Data',
    'Developer_Data_JSONP' => 'Request data to be returned as a JsonP callback',
    'Developer_Data_Locale' => 'Request Language',
    'Developer_Description_Username' => 'Username',
    'Developer_Description_Password' => 'Password',
    'Developer_Description_AndroidAPI' => 'With this API Request you will be able to get auto-generated FreedomCore Armory settings for Android App',
  ),
); ?>