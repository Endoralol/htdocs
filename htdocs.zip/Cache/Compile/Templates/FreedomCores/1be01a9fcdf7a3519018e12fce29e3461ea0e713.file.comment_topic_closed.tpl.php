<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-02 21:26:23
         compiled from "/opt/lampp/htdocs/Templates/FreedomCore/forum/comment_topic_closed.tpl" */ ?>
<?php /*%%SmartyHeaderCode:81906485257507a4f2931d4-92185586%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '1be01a9fcdf7a3519018e12fce29e3461ea0e713' => 
    array (
      0 => '/opt/lampp/htdocs/Templates/FreedomCore/forum/comment_topic_closed.tpl',
      1 => 1464860661,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '81906485257507a4f2931d4-92185586',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_57507a4f303055_63644419',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_57507a4f303055_63644419')) {function content_57507a4f303055_63644419($_smarty_tpl) {?><div id="new-post" class="posting-status-message">
			<?php echo $_smarty_tpl->getConfigVariable('Forum_Topic_Clodsed');?>

	</div><?php }} ?>
