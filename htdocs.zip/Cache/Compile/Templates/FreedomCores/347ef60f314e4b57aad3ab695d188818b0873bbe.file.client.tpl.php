<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-01 22:22:39
         compiled from "E:\OpenServer\domains\wow.loc\Templates\FreedomCore\sidebar\client.tpl" */ ?>
<?php /*%%SmartyHeaderCode:31692574f35ff716623-72383935%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '347ef60f314e4b57aad3ab695d188818b0873bbe' => 
    array (
      0 => 'E:\\OpenServer\\domains\\wow.loc\\Templates\\FreedomCore\\sidebar\\client.tpl',
      1 => 1445375478,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '31692574f35ff716623-72383935',
  'function' => 
  array (
  ),
  'variables' => 
  array (
    'AppName' => 0,
    'Language' => 0,
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_574f35ff749c32_42161210',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_574f35ff749c32_42161210')) {function content_574f35ff749c32_42161210($_smarty_tpl) {?><div id="sidebar-marketing" class="sidebar-module">
    <div class="bnet-offer">
        <div class="bnet-offer-bg">
            <a href="#" target="_blank" id="<?php echo $_smarty_tpl->tpl_vars['AppName']->value;?>
-client" class="bnet-offer-image">
                <img src="/Templates/FreedomCore/images/client/app-screen-<?php echo $_smarty_tpl->tpl_vars['Language']->value;?>
.png" width="300" height="250" alt="" />
            </a>
        </div>
    </div>
</div><?php }} ?>
