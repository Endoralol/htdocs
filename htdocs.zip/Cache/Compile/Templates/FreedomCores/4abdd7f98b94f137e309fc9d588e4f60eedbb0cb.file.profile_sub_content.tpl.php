<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-03 12:14:42
         compiled from "/opt/lampp/htdocs/Templates/FreedomCore/blocks/profile_sub_content.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15476622595750174489ce41-89098377%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '4abdd7f98b94f137e309fc9d588e4f60eedbb0cb' => 
    array (
      0 => '/opt/lampp/htdocs/Templates/FreedomCore/blocks/profile_sub_content.tpl',
      1 => 1464945273,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15476622595750174489ce41-89098377',
  'function' => 
  array (
  ),
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_575017448d85c4_06097479',
  'has_nocache_code' => false,
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_575017448d85c4_06097479')) {function content_575017448d85c4_06097479($_smarty_tpl) {?><div class="summary-bottom-sub-content">
    <div class="summary-bottom-left">

    </div>
</div><?php }} ?>
