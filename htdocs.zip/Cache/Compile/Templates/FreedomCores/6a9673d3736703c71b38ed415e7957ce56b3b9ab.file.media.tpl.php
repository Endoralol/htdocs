<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-05-26 15:03:11
         compiled from "/var/www/u0198439/data/www/pt-wow.ru/Templates/FreedomCore/media.tpl" */ ?>
<?php /*%%SmartyHeaderCode:20275860245746e5ffbdffa1-49263904%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6a9673d3736703c71b38ed415e7957ce56b3b9ab' => 
    array (
      0 => '/var/www/u0198439/data/www/pt-wow.ru/Templates/FreedomCore/media.tpl',
      1 => 1445798322,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '20275860245746e5ffbdffa1-49263904',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5746e5ffc174c0_20314449',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5746e5ffc174c0_20314449')) {function content_5746e5ffc174c0_20314449($_smarty_tpl) {?><?php echo $_smarty_tpl->getSubTemplate ("header.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>

<div id="content">
<div class="content-top body-top">
<div class="content-trail">
<ol class="ui-breadcrumb">
<li itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
<a href="/wow/ru/" rel="np" class="breadcrumb-arrow" itemprop="url">
<span class="breadcrumb-text" itemprop="name">World of Warcraft</span>
</a>
</li>
<li class="last" itemscope="itemscope" itemtype="http://schema.org/SiteNavigationElement">
<a href="/wow/ru/media/" rel="np" itemprop="url">
<span class="breadcrumb-text" itemprop="name">Материалы</span>
</a>
</li>
</ol>
</div>
<div class="content-bot clear"> <div class="media-content">
<div id="media-index">
<div class="media-index-section float-left">
<a class="gallery-title videos" href="videos/">
<span class="view-all"><span class="arrow"></span>Все ролики</span>
<span class="gallery-icon"></span>
Видеоролики <span class="total">(48)</span>
</a>
<div class="section-content">
<a href="videos/?view#/patch-6-2" class="thumb-wrapper video-thumb-wrapper first-video">
<span class="video-info">
<span class="video-title">Обновление 6.2: Ярость Адского Пламени</span>
<span class="video-desc">Подробнее об обновлении 6.2</span>
<span class="date-added">Опубликовано 23/06/2015</span>
</span>
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/videos/patch-6-2/patch-6-2-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
</a>
<a href="videos/?view#/patch-6-0" class="thumb-wrapper video-thumb-wrapper">
<span class="video-info">
<span class="video-title">Вступительный ролик Warlords of Draenor</span>
<span class="video-desc">Подробнее о Warlords of Draenor</span>
<span class="date-added">Опубликовано 13/11/2014</span>
</span>
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/videos/patch-6-0/patch-6-0-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
</a>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
</div>
<div class="media-index-section float-right">
<a class="gallery-title screenshots" href="screenshots/">
<span class="view-all"><span class="arrow"></span>Все скриншоты</span>
<span class="gallery-icon"></span>
Скриншоты <span class="total">(5 043)</span>
</a>
<div class="section-content">
<a class="thumb-wrapper left-col" href="screenshots/selfie?page=1">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/screenshots/selfie/selfie058-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 06/04/2015</span>
</a>
<a class="thumb-wrapper" href="screenshots/screenshot-of-the-day/warlords-of-draenor#/1">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/screenshots/screenshot-of-the-day/warlords-of-draenor/warlords-of-draenor-ss0464-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 21/09/2015</span>
</a>
<a class="thumb-wrapper left-col bottom-row" href="screenshots/transmog/">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/screenshots/transmog/nightelves/nightelf-female036-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 21/02/2012</span>
</a>
<a class="thumb-wrapper bottom-row" href="screenshots/races?keywords=pandaren">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/screenshots/races/pandaren12-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 21/03/2013</span>
</a>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
<div class="media-index-section float-left">
<a href="http://eu.blizzard.com/ru-ru/games/music/" class="gallery-title music" target="_blank">
<span class="view-all">
<span class="arrow"></span>
Все
</span>
<span class="gallery-icon"></span>
Музыка
<span class="total"></span>
</a>
<div class="section-content">
<a class="music-thumb-wrapper" href="http://us.blizzard.com/en-us/games/music/wow-warlords-of-draenor.html" target="_blank">
<span class="album-thumb album-1"></span>
<span class="album-title">World of Warcraft: Warlords of Draenor <em>(Original Game Soundtrack)</em></span>
<span class="date-added">11/13/2014</span>
</a>
<span class="clear"><!-- --></span>
<a class="music-thumb-wrapper" href="http://eu.blizzard.com/ru-ru/games/music/wow-cataclysm.html" target="_blank">
<span class="album-thumb album-2"></span>
<span class="album-title">World of Warcraft: Cataclysm <em>(саундтрек)</em></span>
<span class="date-added">07.12.2010</span>
</a>
<span class="clear"><!-- --></span>
</div>
</div>
<div class="media-index-section float-right">
<a class="gallery-title wallpapers" href="wallpapers/">
<span class="view-all"><span class="arrow"></span>Все обои</span>
<span class="gallery-icon"></span>
Обои <span class="total">(275)</span>
</a>
<div class="section-content">
<a class="thumb-wrapper left-col" href="wallpapers/tcg?view#/tcg26">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/wallpapers/tcg/tcg26/tcg26-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 19/03/2015</span>
</a>
<a class="thumb-wrapper" href="wallpapers/other?view#/warlords-of-draenor">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/wallpapers/other/warlords-of-draenor/warlords-of-draenor-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 19/11/2014</span>
</a>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
<div class="media-index-section float-left">
<a class="gallery-title artwork" href="artwork/">
<span class="view-all"><span class="arrow"></span>Все композиции</span>
<span class="gallery-icon"></span>
Композиции <span class="total">(2 545)</span>
</a>
<div class="section-content">
<a class="thumb-wrapper left-col" href="artwork/wow-warlords-of-draenor">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/artwork/wow-warlords-of-draenor/wowx5-artwork-059-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 16/10/2015</span>
</a>
<a class="thumb-wrapper" href="artwork/wow-warlords-of-draenor">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/artwork/wow-warlords-of-draenor/wowx5-artwork-058-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 03/07/2015</span>
</a>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
</div>
<div class="media-index-section float-right">
<a class="gallery-title fanart" href="fanart/">
<span class="view-all"><span class="arrow"></span>Весь фан-арт</span>
<span class="gallery-icon"></span>
Фан-арт <span class="total">(1 373)</span>
</a>
<div class="section-content">
<a class="thumb-wrapper left-col" href="fanart/?view=fanart-1383">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/fanart/fanart-1383-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 19/10/2015</span>
</a>
<a class="thumb-wrapper" href="fanart/?view=fanart-1382">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/fanart/fanart-1382-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 19/10/2015</span>
</a>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
<div class="media-index-section float-left">
<a class="gallery-title comics" href="comics/">
<span class="view-all"><span class="arrow"></span>Все комиксы</span>
<span class="gallery-icon"></span>
Комиксы <span class="total">(464)</span>
</a>
<div class="section-content">
<a class="thumb-wrapper left-col" href="comics/?view#/comic-2015-10-01">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/comics/comic-2015-10-01-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 15/10/2015</span>
</a>
<a class="thumb-wrapper" href="comics/?view#/comic-2015-07-02">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/comics/comic-2015-07-02-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 06/07/2015</span>
</a>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
</div>
<div class="media-index-section float-right">
<a class="gallery-title costumes" href="costumes/">
<span class="view-all"><span class="arrow"></span>Все костюмы</span>
<span class="gallery-icon"></span>
Костюмы <span class="total">(82)</span>
</a>
<div class="section-content">
<a class="thumb-wrapper left-col" href="costumes/">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/costumes/costumes-0097-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 05/03/2015</span>
</a>
<a class="thumb-wrapper" href="costumes/">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/costumes/costumes-0095-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 05/03/2015</span>
</a>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
<div class="media-index-section float-left">
<a class="gallery-title misc" href="misc/">
<span class="view-all"><span class="arrow"></span>All Misc</span>
<span class="gallery-icon"></span>
Misc Galleries <span class="total">(397)</span>
</a>
<div class="section-content">
<a class="thumb-wrapper left-col" href="misc/desserts">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/misc/desserts/desserts-2014-08-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 22/08/2014</span>
</a>
<a class="thumb-wrapper" href="misc/pumpkins">
<span class="thumb-bg" style="background-image:url(http://media.blizzard.com/wow/media/misc/pumpkins/pumpkin-2014-01-index-thumb.jpg)">
<span class="thumb-frame"></span>
</span>
<span class="date-added">Опубликовано 19/02/2015</span>
</a>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
</div>
<span class="clear"><!-- --></span>
</div>
</div>
<div style="display:none" id="media-preload-container"></div>
</div>
</div>
</div>
<?php echo $_smarty_tpl->getSubTemplate ("footer.tpl", $_smarty_tpl->cache_id, $_smarty_tpl->compile_id, 0, null, array(), 0);?>
<?php }} ?>
