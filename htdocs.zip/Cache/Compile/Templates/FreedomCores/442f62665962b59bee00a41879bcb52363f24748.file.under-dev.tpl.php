<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-01 22:22:39
         compiled from "E:\OpenServer\domains\wow.loc\Templates\FreedomCore\sidebar\under-dev.tpl" */ ?>
<?php /*%%SmartyHeaderCode:15140574f35ff7aa126-11995642%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '442f62665962b59bee00a41879bcb52363f24748' => 
    array (
      0 => 'E:\\OpenServer\\domains\\wow.loc\\Templates\\FreedomCore\\sidebar\\under-dev.tpl',
      1 => 1445375478,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '15140574f35ff7aa126-11995642',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_574f35ff7d9893_84476367',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_574f35ff7d9893_84476367')) {function content_574f35ff7d9893_84476367($_smarty_tpl) {?><div class="sidebar-module" id="sidebar-under-dev">
    <div class="sidebar-title">
        <h3 class="header-3 title-under-dev"><?php echo $_smarty_tpl->getConfigVariable('Latest_Updates_Title');?>
</h3>
    </div>

    <div class="sidebar-content">
        <a href="/wow/en/game/patch-notes/6-0">
            <div class="patch-banner"></div>

            <div class="patch-banner-text">
                The Warlords of Draenor Patch is Live!
            </div></a>
    </div>
</div><?php }} ?>
