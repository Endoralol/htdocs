<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-05-26 11:16:11
         compiled from "/var/www/u0198439/data/www/pt-wow.ru/Templates/FreedomCore/sidebar/under-dev.tpl" */ ?>
<?php /*%%SmartyHeaderCode:1343712335746b0cbb2ea57-77031417%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7371ec4e04599c1811a56c5220a2eb5d06306249' => 
    array (
      0 => '/var/www/u0198439/data/www/pt-wow.ru/Templates/FreedomCore/sidebar/under-dev.tpl',
      1 => 1445375478,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '1343712335746b0cbb2ea57-77031417',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5746b0cbb39577_65625798',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5746b0cbb39577_65625798')) {function content_5746b0cbb39577_65625798($_smarty_tpl) {?><div class="sidebar-module" id="sidebar-under-dev">
    <div class="sidebar-title">
        <h3 class="header-3 title-under-dev"><?php echo $_smarty_tpl->getConfigVariable('Latest_Updates_Title');?>
</h3>
    </div>

    <div class="sidebar-content">
        <a href="/wow/en/game/patch-notes/6-0">
            <div class="patch-banner"></div>

            <div class="patch-banner-text">
                The Warlords of Draenor Patch is Live!
            </div></a>
    </div>
</div><?php }} ?>
