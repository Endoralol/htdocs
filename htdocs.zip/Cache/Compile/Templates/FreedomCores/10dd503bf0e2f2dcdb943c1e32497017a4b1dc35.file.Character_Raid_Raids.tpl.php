<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-01 23:15:33
         compiled from "E:\OpenServer\domains\wow.loc\Templates\FreedomCore\parts\Character_Raid_Raids.tpl" */ ?>
<?php /*%%SmartyHeaderCode:19434574f42652ce2a6-46352643%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '10dd503bf0e2f2dcdb943c1e32497017a4b1dc35' => 
    array (
      0 => 'E:\\OpenServer\\domains\\wow.loc\\Templates\\FreedomCore\\parts\\Character_Raid_Raids.tpl',
      1 => 1445375478,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '19434574f42652ce2a6-46352643',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_574f42652dfb48_45614195',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_574f42652dfb48_45614195')) {function content_574f42652dfb48_45614195($_smarty_tpl) {?><tr class="icons">
    <td></td>
    <td class="mc expansion-0" data-raid="mc">
        <div class="icon">
            <a href="/zone/molten-core/" data-zone="2717">ОН</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="bwl expansion-0" data-raid="bwl">
        <div class="icon">
            <a href="/zone/blackwing-lair/" data-zone="2677">ЛКТ</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="aq10 expansion-0" data-raid="aq10">
        <div class="icon">
            <a href="/zone/ruins-of-ahnqiraj/" data-zone="3429">АК10</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="aq40 expansion-0" data-raid="aq40">
        <div class="icon">
            <a href="/zone/ahnqiraj-temple/" data-zone="3428">АК40</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="kar expansion-1" data-raid="kar">
        <div class="icon">
            <a href="/zone/karazhan/" data-zone="3457">Кар</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="mag expansion-1" data-raid="mag">
        <div class="icon">
            <a href="/zone/magtheridons-lair/" data-zone="3836">Маг</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="gru expansion-1" data-raid="gru">
        <div class="icon">
            <a href="/zone/gruuls-lair/" data-zone="3923">Гру</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="ssc expansion-1" data-raid="ssc">
        <div class="icon">
            <a href="/zone/serpentshrine-cavern/" data-zone="3607">ЗС</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="tk expansion-1" data-raid="tk">
        <div class="icon">
            <a href="/zone/tempest-keep/" data-zone="3845">КБ</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="mh expansion-1" data-raid="mh">
        <div class="icon">
            <a href="/zone/the-battle-for-mount-hyjal/" data-zone="3606">ГХ</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="bt expansion-1" data-raid="bt">
        <div class="icon">
            <a href="/zone/black-temple/" data-zone="3959">ЧХ</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="sp expansion-1" data-raid="sp">
        <div class="icon">
            <a href="/zone/the-sunwell/" data-zone="4075">ПСК</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="voa expansion-2" data-raid="voa">
        <div class="icon">
            <a href="/zone/vault-of-archavon/" data-zone="4603">СА</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="nax expansion-2" data-raid="nax">
        <div class="icon">
            <a href="/zone/naxxramas/" data-zone="3456">Накс</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="os expansion-2" data-raid="os">
        <div class="icon">
            <a href="/zone/the-obsidian-sanctum/" data-zone="4493">ОС</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="eoe expansion-2" data-raid="eoe">
        <div class="icon">
            <a href="/zone/the-eye-of-eternity/" data-zone="4500">ОВ</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="uld expansion-2" data-raid="uld">
        <div class="icon">
            <a href="/zone/ulduar/" data-zone="4273">Ульд</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="ony expansion-0" data-raid="ony">
        <div class="icon">
            <a href="/zone/onyxias-lair/" data-zone="2159">Они</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="toc expansion-2" data-raid="toc">
        <div class="icon">
            <a href="/zone/trial-of-the-crusader/" data-zone="4722">ИК</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="icc expansion-2" data-raid="icc">
        <div class="icon">
            <a href="/zone/icecrown-citadel/" data-zone="4812">ЦЛК</a>
        </div>
    </td>
    <td class="spacer"><div></div></td>
    <td class="rs expansion-2" data-raid="rs">
        <div class="icon">
            <a href="/zone/the-ruby-sanctum/" data-zone="4987">РС</a>
        </div>
    </td>
    
    
        
            
        
    
    
    
        
            
        
    
    
    
        
            
        
    
    
    
        
            
        
    
    
    
        
            
        
    
    
    
        
            
        
    
    
    
        
            
        
    
    
    
        
            
        
    
    
    
        
            
        
    
    
    
        
            
        
    
    
    
        
            
        
    
    
    
        
            
        
    
    
    
        
            
        
    
    <td class="spacer-edge"><div></div></td>
</tr><?php }} ?>
