<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-02 14:25:33
         compiled from "/opt/lampp/htdocs/Templates/FreedomCore/blocks/search_wowguild.tpl" */ ?>
<?php /*%%SmartyHeaderCode:339583972575017ad288e90-46244050%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '0934cdfe570ffe5f9e477049f2b8cf5bcfe7d1c8' => 
    array (
      0 => '/opt/lampp/htdocs/Templates/FreedomCore/blocks/search_wowguild.tpl',
      1 => 1464860657,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '339583972575017ad288e90-46244050',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_575017ad289bf2_81994441',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_575017ad289bf2_81994441')) {function content_575017ad289bf2_81994441($_smarty_tpl) {?><?php }} ?>
