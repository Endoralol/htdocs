<?php $_config_vars = array (
  'sections' => 
  array (
  ),
  'vars' => 
  array (
    'Developer_Page_Title' => 'Для Разработчиков',
    'Developer_API_Header' => 'API',
    'Developer_API_Settings' => 'Настройки',
    'Developer_API_Key' => 'Ваш API ключ',
    'Developer_Authorization_Needed' => 'Для получения ключа API вам необходимо авторизоваться',
    'Developer_API_Key_Get' => 'Получить ключ',
    'Developer_Form_Parameter' => 'Параметр',
    'Developer_Form_Value' => 'Значение',
    'Developer_Form_Description' => 'Описание',
    'Developer_Form_TryIt' => 'Попробовать!',
    'Developer_Form_Reset' => 'Очистить',
    'Developer_Data_JSONP' => 'Request data to be returned as a JsonP callback',
    'Developer_Data_Locale' => 'Язык запроса',
    'Developer_Description_Username' => 'Имя Пользователя',
    'Developer_Description_Password' => 'Пароль Пользователя',
    'Developer_Description_AndroidAPI' => 'С помощью данного вызова API вы сможете получить файл с настройками FreedomCore Armory для вашего сервера',
  ),
); ?>