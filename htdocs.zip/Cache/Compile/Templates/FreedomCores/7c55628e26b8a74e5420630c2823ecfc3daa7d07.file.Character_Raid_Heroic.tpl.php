<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-06-01 23:15:33
         compiled from "E:\OpenServer\domains\wow.loc\Templates\FreedomCore\parts\Character_Raid_Heroic.tpl" */ ?>
<?php /*%%SmartyHeaderCode:11345574f42653096f3-77788344%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '7c55628e26b8a74e5420630c2823ecfc3daa7d07' => 
    array (
      0 => 'E:\\OpenServer\\domains\\wow.loc\\Templates\\FreedomCore\\parts\\Character_Raid_Heroic.tpl',
      1 => 1445375478,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '11345574f42653096f3-77788344',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_574f426530f8c3_06491858',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_574f426530f8c3_06491858')) {function content_574f426530f8c3_06491858($_smarty_tpl) {?><tr class="heroic">
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td data-raid="toc" class="status status-incomplete"><div></div></td>
    <td></td>
    <td data-raid="icc" class="status status-in-progress"><div></div></td>
    <td></td>
    <td data-raid="rs" class="status status-incomplete"><div></div></td>
    <td></td>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <td data-raid="brf" class="status status-incomplete"><div></div></td>
</tr><?php }} ?>
