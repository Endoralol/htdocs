<?php /* Smarty version Smarty-3.1.21-dev, created on 2016-05-26 12:10:50
         compiled from "/var/www/u0198439/data/www/pt-wow.ru/Templates/FreedomCore/parts/Character_Raid_Heroic.tpl" */ ?>
<?php /*%%SmartyHeaderCode:4151189385746bd9a47b357-74095559%%*/if(!defined('SMARTY_DIR')) exit('no direct access allowed');
$_valid = $_smarty_tpl->decodeProperties(array (
  'file_dependency' => 
  array (
    '6ff90c7921b2afa8c50458ba1c0ce7554ce13b2b' => 
    array (
      0 => '/var/www/u0198439/data/www/pt-wow.ru/Templates/FreedomCore/parts/Character_Raid_Heroic.tpl',
      1 => 1445375478,
      2 => 'file',
    ),
  ),
  'nocache_hash' => '4151189385746bd9a47b357-74095559',
  'function' => 
  array (
  ),
  'has_nocache_code' => false,
  'version' => 'Smarty-3.1.21-dev',
  'unifunc' => 'content_5746bd9a48a159_98951962',
),false); /*/%%SmartyHeaderCode%%*/?>
<?php if ($_valid && !is_callable('content_5746bd9a48a159_98951962')) {function content_5746bd9a48a159_98951962($_smarty_tpl) {?><tr class="heroic">
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td></td>
    <td data-raid="toc" class="status status-incomplete"><div></div></td>
    <td></td>
    <td data-raid="icc" class="status status-in-progress"><div></div></td>
    <td></td>
    <td data-raid="rs" class="status status-incomplete"><div></div></td>
    <td></td>
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    <td data-raid="brf" class="status status-incomplete"><div></div></td>
</tr><?php }} ?>
